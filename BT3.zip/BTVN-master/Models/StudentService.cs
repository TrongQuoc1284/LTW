using System.Collections.Generic;
using System.Linq;

namespace BTVN.Models
{
    public static class StudentService
    {
        private static List<Student> _students = new List<Student>();

        public static void AddStudent(Student student)
        {
            _students.Add(student);
        }

        public static int CountBySpecialization(string specialization)
        {
            // Chỉ đếm những sinh viên có chuyên ngành giống với specialization được truyền vào
            return _students.Count(s => s.ChuyenNganh == specialization);
        }

        public static List<Student> GetAllStudents()
        {
            return _students;
        }
    }
} 